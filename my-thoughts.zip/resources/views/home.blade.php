@extends('layouts.app')

@section('content')
<div class="container">

        <my-thoughts-component></my-thoughts-component>
   
</div>
@endsection
